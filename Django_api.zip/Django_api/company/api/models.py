from django.db import models

# Create your models here.
class Quote(models.Model):
    id=models.AutoField(primary_key=True)
    text=models.TextField()
    author=models.CharField(max_length=100)
    date=models.DateTimeField(auto_now=True)
    active=models.BooleanField(default=True)

