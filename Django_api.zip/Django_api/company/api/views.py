from rest_framework import viewsets
from .models import Quote
from .serializers import QuoteSerializer
import random
from rest_framework.decorators import action
from rest_framework.response import Response
from django.shortcuts import render
from django.http import JsonResponse


class QuoteViewSet(viewsets.ModelViewSet):
    queryset = Quote.objects.all()
    serializer_class = QuoteSerializer




    @action(detail=False, methods=['get'], url_path='random')
    def random_quote(self, request):
        count = self.queryset.count()
        if count == 0:
            return Response({"detail": "No quotes available."}, status=404)
        random_index = random.randint(0, count - 1)
        random_quote = self.queryset.all()[random_index]
        serializer = self.get_serializer(random_quote)
        return Response(serializer.data)
    


    @action(detail=False, methods=['delete'], url_path='delete-random')
    def delete_random_quote(self, request):
        count = self.queryset.count()
        if count == 0:
            return Response({"detail": "No quotes available to delete."}, status=404)
        random_index = random.randint(0, count - 1)
        random_quote = self.queryset.all()[random_index]
        random_quote.delete()
        return Response({"detail": "Random quote deleted."}, status=204)


def index(request):
    return render(request, 'api/index.html')

def random_quote_api_view(request):
    random_quote = Quote.objects.order_by('?').first()
    if random_quote:
        data = {
            'text': random_quote.text,
            'author': random_quote.author
        }
        return JsonResponse(data)
    else:
        return JsonResponse({'error': 'No quotes available'}, status=404)

