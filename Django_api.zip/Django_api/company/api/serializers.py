from rest_framework import serializers
from .models import Quote

class QuoteSerializer(serializers.ModelSerializer):
    Quote_id=serializers.ReadOnlyField()
    class Meta:
        model = Quote
        fields = '__all__'
